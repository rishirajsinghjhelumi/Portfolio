The source code for the library can be found at

  https://github.com/fabi1cazenave/webL10n
